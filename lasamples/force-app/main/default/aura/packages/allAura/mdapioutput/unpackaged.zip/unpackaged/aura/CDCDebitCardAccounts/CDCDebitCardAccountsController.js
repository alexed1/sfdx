({
    doInit: function(cmp,event,helper){
        helper.loadContacts(cmp);
        cmp.set('v.debitCardId', helper.getUrlParameter('debitCardId'));
    },

    toggleBoxSelected: function(cmp,event,helper){
        var arr = [];
        arr = cmp.find("mainContactList").getElement().childNodes;
        for(var i = 0; i < arr.length;i++) {
            $A.util.removeClass(arr[i], "selected");
        }
        var targetElement = event.currentTarget;
        cmp.set('v.selectedContactId', targetElement.dataset.id);
        $A.util.addClass(targetElement, "selected");
        $A.util.removeClass(cmp.find('next-step-button'),'disabled');
    },

    assignContactToDebitCard: function(cmp,event,helper){

        cmp.set('v.showSpinner',true);

        var absPath = window.location.protocol + '//' + window.location.hostname + '/s/debit-card-preview';
        var contactId = cmp.get('v.selectedContactId');
        var debitCardId = cmp.get('v.debitCardId');

        var action = cmp.get("c.updateCustomDebitCardObject");
        action.setParams({
            'contactId': contactId,
            'cardId' : debitCardId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": absPath  + "?debitCardId=" + debitCardId+ '&contactId=' + contactId,
                    "isredirect" : true
                });
                urlEvent.fire();
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                }
                else {
                     console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },

    refreshPage: function(cmp,event,helper){
        helper.loadContacts(cmp);
    }

})