({
    toggleBoxSelected: function(cmp, event){

        //clean all selections
        $A.util.removeClass(cmp.find('personal-check-wrapper'), 'selected');
        $A.util.removeClass(cmp.find('business-check-wrapper'), 'selected');
        $A.util.removeClass(cmp.find('astro-check-wrapper'), 'selected');
        $A.util.removeClass(cmp.find('ohana-check-wrapper'), 'selected');
        $A.util.removeClass(cmp.find('adventures-check-wrapper'), 'selected');
        $A.util.removeClass(cmp.find('friends-check-wrapper'), 'selected');

        var elementId = event.getSource().getLocalId();
        var cmpTarget = cmp.find(elementId + '-wrapper');
        $A.util.addClass(cmpTarget, 'selected');
        $A.util.removeClass(cmp.find('next-step-button'),'disabled');
    },
    
    doInit: function(cmp){
        cmp.set('v.currentStep', 1);
    },
    
    nextStep: function(cmp, event, helper){

        var currentStep = cmp.get('v.currentStep') == 3 ? 31 : cmp.get('v.currentStep') + 1;
    	cmp.set('v.currentStep' , currentStep);
        cmp.set('v.currentStepTitle',helper.getStepTitle(currentStep));

        if(currentStep == 3 || currentStep == 31){
            helper.loadContacts(cmp);
        }

        if(currentStep <= 31){
           cmp.set('v.currentStepButtonLabel', helper.getStepButtonLabel(currentStep));
           $A.util.addClass(cmp.find('next-step-button'),'disabled');
        }
        else{
            cmp.set('v.showStepButton', false);
        }
	},
})