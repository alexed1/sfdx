({
	getPetById : function(swaggerPetstore, pet) {
		return new Promise($A.getCallback(function(resolve, reject) {
            var petApi = new swaggerPetstore.PetApi();
            petApi.getPetById(pet, $A.getCallback(function(error, data, response) {
              if (error) {
                  reject(Error(error));
              } else {
                  resolve(response.body);
              }
            }));
        }));
	},
        defer : function() {
            var res, rej;
            var promise = new Promise(function(resolve, reject) {
                res = resolve;
                rej = reject;
            });
            promise.resolve = res;
            promise.reject = rej;
            return promise;
    }
})