({
	updateValue : function(component, event, helper) {
        //component.set("v.FirstName", component.find("FirstName").get("v.value"));
	}
})