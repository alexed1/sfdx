({
	invoke : function(component, event, helper) {
       var args = event.getParam("arguments");
       var callback = args.callback;
       
       var xhttp = new XMLHttpRequest();
       xhttp.onreadystatechange = $A.getCallback(function() {
	    	   if (this.readyState === 4) { // DONE
	    	        if (this.status === 200) {
	    	        	var response = JSON.parse(xhttp.responseText);
	    	 	       	component.set("v.churnVal", response);
	    	 	       	callback("SUCCESS");
	    	        } else {
	    	 	       	callback("ERROR", this.statusText);
	    	        }
	    	    }
	       });
//       xhttp.onerror =  $A.getCallback(function(event) {
//           callback("ERROR", event.target.statusText);
//       });

        
       xhttp.open("GET", "https://upp57qbj5b.execute-api.us-west-1.amazonaws.com/production/customer/46/churn", true);
       xhttp.setRequestHeader("Content-type", "application/text");
       xhttp.send();
    }
})