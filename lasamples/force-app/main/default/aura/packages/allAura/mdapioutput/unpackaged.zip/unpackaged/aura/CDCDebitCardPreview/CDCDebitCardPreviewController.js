({
    doInit: function(cmp,event,helper){
        cmp.set('v.debitCardId', helper.getUrlParameter('debitCardId'));
        cmp.set('v.selectedContactId', helper.getUrlParameter('contactId'));
        helper.loadContact(cmp);
    },

    submitApplication: function(cmp,event){
        cmp.set('v.showSpinner',true);
        var absPath = window.location.protocol + '//' + window.location.hostname + '/s/debit-card-confirmation';
        var debitCardId = cmp.get('v.debitCardId');
        var action = cmp.get("c.updateDebitCardObjectStatus");
        action.setParams({'cardId': debitCardId});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": absPath,
                    "isredirect" : true
                });
                urlEvent.fire();
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                }
                else {
                     console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    }
})