({
    doneRendering: function(cmp, event, helper){
        var currentStep = cmp.get('v.currentStep');
        var isActiveCss = 'slds-is-active';
        var isCompletedCss = 'slds-is-completed';
        var progress = cmp.find('progressPercentage');
        var progress0 = 'progress0';
        var progress25 = 'progress25';
        var progress75 = 'progress75';
        var progress100 = 'progress100';

        var arr = [];
        arr = cmp.find('itemList').getElement().childNodes;

        for(var i = 0; i < arr.length;i++) {
            $A.util.removeClass(arr[i], isCompletedCss);
            $A.util.removeClass(arr[i], isActiveCss);
        }

        switch(currentStep){
            case 1: default:
                $A.util.addClass(arr[0], isActiveCss);
                $A.util.addClass(progress, progress0);
            break;
            case 2:
                $A.util.addClass(arr[0], isCompletedCss);
                $A.util.addClass(arr[1], isActiveCss);
                $A.util.addClass(progress, progress25);
            break;
            case 3:
                $A.util.addClass(arr[0], isCompletedCss);
                $A.util.addClass(arr[1], isCompletedCss);
                $A.util.addClass(arr[2], isActiveCss);
                $A.util.addClass(progress, progress75);
            break;
            case 4:
                $A.util.addClass(arr[0], isCompletedCss);
                $A.util.addClass(arr[1], isCompletedCss);
                $A.util.addClass(arr[2], isCompletedCss);
                $A.util.addClass(arr[3], isActiveCss);
                $A.util.addClass(progress, progress100);
            break;

        }
    }
})