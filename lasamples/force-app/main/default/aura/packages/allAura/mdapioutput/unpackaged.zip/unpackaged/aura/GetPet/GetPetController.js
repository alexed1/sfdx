({
    init : function(component, event, helper) {
        component.set("v.scriptLoaded", helper.defer());
    },
    scriptsLoaded : function(component, event, helper) {
        component.get("v.scriptLoaded").resolve(true);
    },
    invoke : function(component, event, helper) {
    	var args = event.getParam("arguments");
        var callback = args.callback;

        component.get("v.scriptLoaded").then($A.getCallback(function() {
	    	var swaggerPetstore = require("swagger_petstore");
	        var petId = component.get("v.petId");
	        helper.getPetById(swaggerPetstore, petId).then(
	            $A.getCallback(function(result) {
	                var petName = result.name;
	              	component.set("v.petName", petName.toString());
	              	callback("SUCCESS");
	        	})
	        ).catch($A.getCallback(function(error) {
	        		callback("ERROR", error.message);
	        }));
        }));
    }
})