({
    /*init : function (component) {
        if(!component.get("v.isChecks")) {
            var Disney = component.find("Disney");
            
        }
    },*/
    
	onSelect : function (component, event) {
        var currentSelected = component.find(component.get("v.selectedCheck"));
        $A.util.removeClass(currentSelected, "selected");
        var selectedItem = component.find(event.currentTarget.dataset.value);
        $A.util.addClass(selectedItem, "selected");
		component.set("v.selectedCheck", event.currentTarget.dataset.value);
	},
    
    onMouseOver : function (component, event) {
        var selectedItem = component.find(event.currentTarget.dataset.value);
        $A.util.addClass(selectedItem, "hover");
    },
    
    onMouseOut : function (component, event) {
        var selectedItem = component.find(event.currentTarget.dataset.value);
        $A.util.removeClass(selectedItem, "hover");
    }
})