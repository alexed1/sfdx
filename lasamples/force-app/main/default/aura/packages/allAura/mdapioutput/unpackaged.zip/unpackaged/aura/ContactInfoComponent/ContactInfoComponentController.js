({
    handleClick : function (component) {
        component.set("v.update", true);
        component.set("v.tempFirstName", component.get("v.firstName"));
        component.set("v.tempLastName", component.get("v.lastName"));
        component.set("v.tempStreetAddress", component.get("v.streetAddress"));
        component.set("v.tempCity", component.get("v.city"));
        component.set("v.tempState", component.get("v.state"));
        component.set("v.tempZipCode", component.get("v.zipCode"));
        //component.set("v.tempUpdate", false);
    },
    
    onSave : function(component) {
        component.set("v.firstName", component.find("firstName").get("v.value"));
        component.set("v.lastName", component.find("lastName").get("v.value"));
        component.set("v.streetAddress", component.find("streetAddress").get("v.value"));
        component.set("v.city", component.find("city").get("v.value"));
        component.set("v.state", component.find("state").get("v.value"));
        component.set("v.zipCode", component.find("zipCode").get("v.value"));
        component.set("v.update", false);
    },
    
    onCancel : function(component) {
        component.set("v.firstName", component.get("v.tempFirstName"));
        component.set("v.lastName", component.get("v.tempLastName"));
        component.set("v.streetAddress", component.get("v.tempStreetAddress"));
        component.set("v.city", component.get("v.tempCity"));
        component.set("v.state", component.get("v.tempState"));
        component.set("v.zipCode", component.get("v.tempZipCode"));
        component.set("v.update", false);
    }
})