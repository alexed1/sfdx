({
	getStepTitle: function(step){
        switch(step){
            case 1: default:
            	return '1. What purpose is this debit card for?';
            break;
            case 2:
                return '2. Choose your card design';	
            break;
            case 3:
                return '3. Your personal details';
            break;
            case 31:
                return '3. Your card preview';
            break;
        } 
    },
    getStepButtonLabel: function(step){
        switch(step){
            case 1:default:
                return 'Next: Choose your card design';
            break;

            case 2:
                return 'Next: Enter personal details';
            break;

            case 3: case 31:
                return 'Next: Preview card';
            break;
        }
    },

    loadContacts : function(cmp) {
        // Load all contact data
        var action = cmp.get("c.getContacts");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                cmp.set("v.contactList", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    }
})