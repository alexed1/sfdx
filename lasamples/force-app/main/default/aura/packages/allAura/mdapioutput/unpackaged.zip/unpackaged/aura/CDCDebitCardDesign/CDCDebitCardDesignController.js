({
    toggleBoxSelected: function(cmp, event){

        $A.util.removeClass(cmp.find('astro-check-wrapper'), 'selected');
        $A.util.removeClass(cmp.find('ohana-check-wrapper'), 'selected');
        $A.util.removeClass(cmp.find('adventures-check-wrapper'), 'selected');
        $A.util.removeClass(cmp.find('friends-check-wrapper'), 'selected');
        var elementId = event.getSource().getLocalId();
        var cmpTarget = cmp.find(elementId + '-wrapper');
        $A.util.addClass(cmpTarget, 'selected');
        $A.util.removeClass(cmp.find('next-step-button'),'disabled');
    },

    createDebitCardObject: function(cmp,event,helper){
        var absPath = window.location.protocol + '//' + window.location.hostname;
        var action = cmp.get("c.createCustomDebitCardObject");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === "SUCCESS"){
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": absPath  + "/s/debit-card-accounts?debitCardId=" + response.getReturnValue(),
                    "isredirect" : true
                });
                urlEvent.fire();
            }
            else if (state === "INCOMPLETE") {
                // do something
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },

})