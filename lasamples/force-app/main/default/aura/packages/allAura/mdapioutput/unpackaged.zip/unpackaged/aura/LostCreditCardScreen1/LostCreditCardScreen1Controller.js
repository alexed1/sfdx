({
    toggleBoxSelected: function(cmp,event,helper){
        var arr = [];
        arr = cmp.find("mainList").getElement().childNodes;
        for(var i = 0; i < arr.length;i++) {
            $A.util.removeClass(arr[i], "selected");
        }
        var targetElement = event.currentTarget;
        $A.util.addClass(targetElement, "selected");
    },
})