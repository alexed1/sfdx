({
    toggleBoxSelected: function(cmp, event){

            //clean all selections
            $A.util.removeClass(cmp.find('personal-check-wrapper'), 'selected');
            $A.util.removeClass(cmp.find('business-check-wrapper'), 'selected');

            var elementId = event.getSource().getLocalId();
            var cmpTarget = cmp.find(elementId + '-wrapper');
            $A.util.addClass(cmpTarget, 'selected');
            $A.util.removeClass(cmp.find('next-step-button'),'disabled');
        },
})