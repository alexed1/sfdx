({
    getLocalList: function(component) {
        var objectType = component.get("v.sObjectName");
        var spinner = component.find('spinner');
		$A.util.removeClass(spinner, "slds-hide");
        var searchTerm = component.find("searchTerm").get("v.value");
		if (!searchTerm)
        {
            searchTerm = component.get("v.defaultSearch");
        }
        var location = component.get("v.location");
        var action = component.get("c.getListByAddress");
        var recID = component.get("v.recordId");
        console.log ("The record id is", recID);
        location = JSON.parse(location);
        action.setParams({
                       "recordId": recID,
            "objectType": objectType,
             "searchQuery": searchTerm
        });
        action.setCallback(this, function(response) {
            this.doLayout(response, component);
        });
        $A.enqueueAction(action);
    },
    // add doLayout function
    doLayout: function(response, component) {
        console.log("Response:" + response);
        var data = JSON.parse(response.getReturnValue());
        console.log("data: " + data);
        component.set("v.restaurantList", data.bizArray);
        console.log("The Data: ", data);
        var spinner = component.find('spinner');
		$A.util.addClass(spinner, "slds-hide");
        var warning = component.find('warning');
if (data.error) {
    component.set("v.errorMessage", data.error);            
    $A.util.removeClass(warning, 'slds-hide');
} else {
    $A.util.addClass(warning, 'slds-hide');
}


    }    
})